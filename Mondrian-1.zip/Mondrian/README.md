# Projet d'Ocaml

### Marie Bétend, Paul Bach

Nous avons créé un script nommé _mondrian.sh_ permettant de compiler, d'executer puis de supprimer les fichiers générés lors de la compilation.
Pour l'utiliser, il suffit de taper la commande **./mondrian.sh**.

La page paramètres du jeu permet de modifier la valeur des champs indiqués. Pour ce faire, il suffit de cliquer sur le champs correspondants et d'effacer ou d'écrire les caractères souhaités.

La génération de solution à partir d'un coloriage partiel s'effectue avec le bouton Solution courante. Cependant, la génération des formes normales conjonctives est parfois trop coûteuse. Dans ce cas, un message d'erreur l'expliquera.
